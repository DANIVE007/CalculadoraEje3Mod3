package com.example.calculadoraeje3mod3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculadora extends AppCompatActivity {

    EditText numero1, numero2;
    TextView textResultado;
    Button btnSuma, btnResta, btnMultiplicacion, btnDivision;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora);

        // Asociar los objetos de la UI con las variables
        numero1 = findViewById(R.id.numero1);
        numero2 = findViewById(R.id.numero2);
        textResultado = findViewById(R.id.textResultado);
        btnSuma = findViewById(R.id.btnSuma);
        btnResta = findViewById(R.id.btnResta);
        btnMultiplicacion = findViewById(R.id.btnMultiplicacion);
        btnDivision = findViewById(R.id.btnDivision);

        // Configurar los listeners para cada botón
        btnSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                int resultado = num1 + num2;
                textResultado.setText(String.valueOf(resultado));
            }
        });

        btnResta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                int resultado = num1 - num2;
                textResultado.setText(String.valueOf(resultado));
            }
        });

        btnMultiplicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                int resultado = num1 * num2;
                textResultado.setText(String.valueOf(resultado));
            }
        });

        btnDivision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(numero1.getText().toString());
                int num2 = Integer.parseInt(numero2.getText().toString());
                if (num2 != 0) {
                    int resultado = num1 / num2;
                    textResultado.setText(String.valueOf(resultado));
                } else {
                    textResultado.setText("Error: División por 0");
                }
            }
        });
    }
}
